﻿namespace lab1
{
    class Game{
        public string opponentName{get;}
        public int rating1{get;}
        public int rating2{get;}
        public int ratingpf{get; }
        public int id{get;}
        public string result{get;}
        public Game(string name, int Id, string Result,int rat1,int rat2,int rat) {
            opponentName = name;
            rating1 = rat1;
            rating2 = rat2;
            id = Id;
            result = Result;
            ratingpf = rat;
        }
    }
}