﻿using System;
using System.Collections.Generic;

namespace lab1
{
    class GameAccount{
        public string UserName{get; set;}
        public int CurrentRating{get; set;}
        public int GamesCount{get; set; }
        private List<Game> AllGames = new List<Game>();
        public GameAccount(string name) {
            UserName = name;
            CurrentRating = 20;
            GamesCount = 0;
        }
  
        public void WinGame(int rating, string name){
            if(rating >= 0)
            {
                int rating2 = CurrentRating+rating;
                Game game = new Game(name,GamesCount+1,"Перемога", CurrentRating, rating2,rating);
                CurrentRating += rating;
                GamesCount++;
                AllGames.Add(game);
            }
            if(rating < 0) Console.WriteLine ("Помилка. Рейтинг не може бути менше 0.");
        }
  
        public void LoseGame(int rating, string name){
            int rating2;
            if(rating >= 0)
            {
                if(CurrentRating - rating >= 1) rating2 = CurrentRating - rating;
                else rating2 = 1;
                Game game = new Game(name,GamesCount+1,"Програш", CurrentRating, rating2,rating);
                if(CurrentRating-rating>=1) CurrentRating-=rating;
                else CurrentRating=1;
                GamesCount++;
                AllGames.Add(game);
            }
        }
  
        public void GetStats(){
            Console.WriteLine (UserName+" статистика: ");
            Console.WriteLine ("Id|Против кого|Рейтинг 1 гравця|Рейтинг 2 гравця|Рейтинг за який грають|Результат");
            for(int i = 0;i < AllGames.Count;i++)
            {
                Console.WriteLine (AllGames[i].id+" |"+AllGames[i].opponentName +      "       | " +AllGames[i].rating1+"            |   "+AllGames[i].rating2+"            | "+AllGames[i].ratingpf+"               | "+AllGames[i].result);
            }
        }
        public void User(){
            Console.WriteLine ("\nІнофрмація про ігрока " +UserName+ ":");
            Console.WriteLine ("Ім'я "+ UserName+"\nРейтинг "+CurrentRating+"\nКількість зіграних ігор "+GamesCount);
        }
    }
}