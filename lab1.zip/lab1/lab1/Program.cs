﻿namespace lab1
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            GameAccount user1 = new GameAccount("Юлія");
            GameAccount user2 = new GameAccount("Віктор");
            user1.WinGame(3, user2.UserName);
            user2.LoseGame(3, user1.UserName);
            user2.WinGame(5, user1.UserName);
            user1.LoseGame(5, user2.UserName);
            user2.WinGame(7, user1.UserName);
            user1.LoseGame(7, user2.UserName);
            user2.WinGame(-1, user1.UserName);
    
            user1.GetStats();
            user2.GetStats();
            user1.User();
            user2.User();
        }
    }
}